import React from 'react';
import { Grid, Text, View, StyleSheet } from 'react-native';

function App() {
  const cores = StyleSheet.create({
    amarelo: { backgroundColor: 'yellow' },
    ciano: { backgroundColor: 'cyan' },
    verde: { backgroundColor: 'green' },
    roxo: { backgroundColor: 'purple' },
    vermelho: { backgroundColor: 'red' },
    azul: { backgroundColor: 'blue' },
    preto: { backgroundColor: 'black' },
    branco: { backgroundColor: 'white' },
    cinza: { backgroundColor: 'grey' },
  });

  const secoes = StyleSheet.create({
    topo: {
      width: 'auto',
      height: 500,
      flexDirection: 'row',
      backgroundColor: 'black',
    },
    meio: {
      width: 'auto',
      height: 150,
      flexDirection: 'row',
      backgroundColor: 'black',
    },
    fim: {
      width: 'auto',
      height: 300,
      flexDirection: 'row',
      backgroundColor: 'black',
    },
    barras: { width: 48 },
    barras2: { width: 65 },
  });

  return (
    <View>
      <View style={secoes.topo}>
        <View style={[cores.branco, secoes.barras]}></View>
        <View style={[cores.amarelo, secoes.barras]}></View>
        <View style={[cores.ciano, secoes.barras]}></View>
        <View style={[cores.verde, secoes.barras]}></View>
        <View style={[cores.roxo, secoes.barras]}></View>
        <View style={[cores.vermelho, secoes.barras]}></View>
        <View style={[cores.azul, secoes.barras]}></View>
      </View>
      <View style={secoes.meio}>
        <View style={[cores.azul, secoes.barras]}></View>
        <View style={[cores.preto, secoes.barras]}></View>
        <View style={[cores.roxo, secoes.barras]}></View>
        <View style={[cores.preto, secoes.barras]}></View>
        <View style={[cores.ciano, secoes.barras]}></View>
        <View style={[cores.preto, secoes.barras]}></View>
        <View style={[cores.branco, secoes.barras]}></View>
      </View>
      <View style={secoes.fim}>
        <View style={[cores.azul, secoes.barras2]}></View>
        <View style={[cores.branco, secoes.barras2]}></View>
        <View style={[cores.roxo, secoes.barras2]}></View>
        <View style={[cores.preto, secoes.barras2]}></View>
        <View style={[cores.cinza, secoes.barras]}></View>
        <View style={[cores.preto, secoes.barras]}></View>
      </View>
    </View>
  );
}

export default App;