import React from 'react';
import { Text, View, Button } from 'react-native';

function App() {
  return (
  <>
    <View style={{flexDirection: 'row', backgroundColor: 'orange', flex: 5, alignItems: 'stretch'}}>
      <View style={{backgroundColor: 'white', flex: 0.5}}></View>
      <View style={{backgroundColor: 'yellow', flex: 0.5}}></View>
      <View style={{backgroundColor: 'cyan', flex: 0.5}}></View>
      <View style={{backgroundColor: 'green', flex: 0.5}}></View>
      <View style={{backgroundColor: 'magenta', flex: 0.5}}></View>
      <View style={{backgroundColor: 'red', flex: 0.5}}></View>
      <View style={{backgroundColor: 'blue', flex: 0.5}}></View> 
    </View>

    <View style={{flexDirection: 'row', backgroundColor: 'purple', flex: 1, alignItems: 'stretch'}}>
      <View style={{backgroundColor: 'steelblue', flex: 0.25}}></View>
      <View style={{backgroundColor: 'white', flex: 0.25}}></View>
      <View style={{backgroundColor: 'indigo', flex: 0.25}}></View>
      <View style={{backgroundColor: 'black', flex: 0.5}}></View>
    </View>
  </>
  )
}

export default App;